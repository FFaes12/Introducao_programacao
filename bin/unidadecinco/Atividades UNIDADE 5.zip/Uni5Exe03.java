package unidadecinco;

public class Uni5Exe03 {
  public static void main(String[] args) {
  double soma = 0;
  for (int contador = 1; contador <= 100; contador++){
    soma += 1.0/contador;
  }
  System.out.println(soma);
  }
}
